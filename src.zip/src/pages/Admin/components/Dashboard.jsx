import { useEffect, useState } from 'react'
import { ArrowRight, Calendar, FileText, Heart, Image, TrendingUp, Users } from 'lucide-react'
import { useAdminTheme } from '../AdminThemeContext'

const Dashboard = ({ onNavigate }) => {
  const { darkMode } = useAdminTheme()
  const [counts, setCounts] = useState({
    events: 0,
    media: 0,
    blog: 0,
    testimonies: 0,
    visitors: 0
  })

  useEffect(() => {
    const readArrayCount = (key) => {
      const raw = localStorage.getItem(key)
      if (!raw) return 0
      try {
        const parsed = JSON.parse(raw)
        return Array.isArray(parsed) ? parsed.length : 0
      } catch {
        return 0
      }
    }

    setCounts({
      events: readArrayCount('admin_events'),
      media: readArrayCount('admin_media'),
      blog: readArrayCount('admin_blog_posts'),
      testimonies: readArrayCount('admin_testimonies'),
      visitors: readArrayCount('admin_visitors')
    })
  }, [])

  const stats = [
    { label: 'Total Events', value: String(counts.events), icon: Calendar, color: '#5a4494', link: 'events' },
    { label: 'Media Items', value: String(counts.media), icon: Image, color: '#2d3a7a', link: 'media' },
    { label: 'Blog Posts', value: String(counts.blog), icon: FileText, color: '#d4a82e', link: 'blog' },
    { label: 'Testimonies', value: String(counts.testimonies), icon: Heart, color: '#e11d48', link: 'testimonies' },
    { label: 'Visitors', value: String(counts.visitors), icon: Users, color: '#10b981', link: 'visitors' }
  ]

  const recentActivities = [
    { type: 'event', text: 'Event "Youth Summit 2026" created', time: '2 hours ago' },
    { type: 'media', text: '12 new media items uploaded', time: '5 hours ago' },
    { type: 'blog', text: 'New blog post published', time: '1 day ago' },
    { type: 'visitor', text: '23 new subscribers joined', time: '1 day ago' }
  ]

  const surface = darkMode ? '#1a2235' : 'white'
  const borderColor = darkMode ? '#2a3550' : '#e5e7eb'
  const textPrimary = darkMode ? '#e2e8f0' : '#111827'
  const textSecondary = darkMode ? '#7f93b3' : '#6b7280'
  const textLabel = darkMode ? '#94afd4' : '#374151'
  const rowBg = darkMode ? '#222c40' : '#f9fafb'

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ margin: '0 0 0.5rem', fontSize: '2rem', color: textPrimary }}>
          Dashboard
        </h1>
        <p style={{ margin: 0, color: textSecondary }}>
          Manage your website content and monitor activity
        </p>
      </div>

      <div style={{ overflowX: 'auto', paddingBottom: '0.35rem', marginBottom: '2rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, minmax(220px, 1fr))', gap: '1.5rem', minWidth: '1160px' }}>
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <div
                key={stat.label}
                onClick={() => onNavigate(stat.link)}
                style={{
                  background: surface,
                  padding: '1.5rem',
                  borderRadius: '0.75rem',
                  border: `1px solid ${borderColor}`,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem',
                  cursor: 'pointer',
                  transition: 'transform 0.2s, box-shadow 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)'
                  e.currentTarget.style.boxShadow = '0 10px 15px -3px rgba(0,0,0,0.1)'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)'
                  e.currentTarget.style.boxShadow = 'none'
                }}
              >
                <div
                  style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '0.75rem',
                    background: `${stat.color}15`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: stat.color
                  }}
                >
                  <Icon size={24} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '0.875rem', color: textSecondary }}>
                    {stat.label}
                  </div>
                  <div style={{ fontSize: '1.875rem', fontWeight: 700, color: textPrimary }}>
                    {stat.value}
                  </div>
                </div>
                <ArrowRight size={20} style={{ color: darkMode ? '#5a7099' : '#9ca3af' }} />
              </div>
            )
          })}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
        <div style={{ 
          background: surface, 
          padding: '1.5rem', 
          borderRadius: '0.75rem',
          border: `1px solid ${borderColor}`
        }}>
          <h2 style={{ margin: '0 0 1.5rem', fontSize: '1.25rem', color: textPrimary }}>
            Recent Activity
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {recentActivities.map((activity, index) => (
              <div key={index} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.75rem', background: rowBg, borderRadius: '0.5rem' }}>
                <span style={{ fontSize: '0.875rem', color: textLabel }}>{activity.text}</span>
                <span style={{ fontSize: '0.75rem', color: darkMode ? '#5a7099' : '#9ca3af' }}>{activity.time}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{ 
          background: surface, 
          padding: '1.5rem', 
          borderRadius: '0.75rem',
          border: `1px solid ${borderColor}`
        }}>
          <h2 style={{ margin: '0 0 1rem', fontSize: '1.25rem', color: textPrimary }}>
            Quick Actions
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <button
              onClick={() => onNavigate('events')}
              style={{
                padding: '0.75rem 1.5rem',
                background: '#5a4494',
                color: 'white',
                border: 'none',
                borderRadius: '0.5rem',
                fontSize: '0.875rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              Create Event
              <Calendar size={16} />
            </button>
            <button
              onClick={() => onNavigate('media')}
              style={{
                padding: '0.75rem 1.5rem',
                background: '#2d3a7a',
                color: 'white',
                border: 'none',
                borderRadius: '0.5rem',
                fontSize: '0.875rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              Upload Media
              <Image size={16} />
            </button>
            <button
              onClick={() => onNavigate('blog')}
              style={{
                padding: '0.75rem 1.5rem',
                background: '#d4a82e',
                color: 'white',
                border: 'none',
                borderRadius: '0.5rem',
                fontSize: '0.875rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              New Blog Post
              <FileText size={16} />
            </button>
            <button
              onClick={() => onNavigate('testimonies')}
              style={{
                padding: '0.75rem 1.5rem',
                background: '#e11d48',
                color: 'white',
                border: 'none',
                borderRadius: '0.5rem',
                fontSize: '0.875rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              Add Testimony
              <Heart size={16} />
            </button>
            <button
              onClick={() => onNavigate('analytics')}
              style={{
                padding: '0.75rem 1.5rem',
                background: darkMode ? '#1e2840' : 'white',
                color: darkMode ? '#94afd4' : '#374151',
                border: `1px solid ${darkMode ? '#2a3550' : '#d1d5db'}`,
                borderRadius: '0.5rem',
                fontSize: '0.875rem',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}
            >
              View Analytics
              <TrendingUp size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
